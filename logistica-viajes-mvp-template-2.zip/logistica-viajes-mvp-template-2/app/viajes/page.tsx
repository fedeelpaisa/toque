import { OperationsApp } from "@/components/operations-app";

export default function TravelsPage() {
  return <OperationsApp initialView="travels" />;
}
