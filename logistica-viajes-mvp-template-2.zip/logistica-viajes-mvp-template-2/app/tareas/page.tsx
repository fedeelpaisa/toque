import { OperationsApp } from "@/components/operations-app";

export default function TasksPage() {
  return <OperationsApp initialView="table" />;
}
